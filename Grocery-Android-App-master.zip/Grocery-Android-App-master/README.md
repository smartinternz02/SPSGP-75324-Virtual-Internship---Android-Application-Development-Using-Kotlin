# About Me
## My name is Sagar Bangade

Smartinternz Dashboard Link- https://smartinternz.com/student-profile/feed/U0IyMDIyMDIyMTkzNg==

Google Developer Profile Link- https://g.dev/sagarbangade

Project - Grocery Android App
This Project is a part of Google Supported Virtual Internship - Android App Development Using Kotlin.

As we can't remember everything, users frequently forget to buy the things they want to buy. However, with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.

Demonstration video of App- https://youtu.be/DFju7XqNHxw
